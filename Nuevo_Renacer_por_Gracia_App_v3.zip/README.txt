Nuevo Renacer por Gracia - versión 3
PIN demo: 2026
Para compartir datos entre celulares se requiere HTTPS y base de datos.